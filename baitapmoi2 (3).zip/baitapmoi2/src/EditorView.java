import java.util.List;

public class EditorView {
    public void displayLines(List<String> lines) {
        for (String line : lines) {
            System.out.println(line);
        }
    }
}